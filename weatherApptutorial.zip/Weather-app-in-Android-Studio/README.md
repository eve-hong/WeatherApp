# WeatherAppInAndroidStudio
This is amazing weather app which uses open weather api and it can fetch the weather of your current location or any particular city. The UI of the app is completely responsive.

![Copy of seek bar (3)](https://user-images.githubusercontent.com/64765400/103085628-1c2cac00-4597-11eb-9c40-3d1663e0a39a.png)

## Features
- Weather update
- Responsive ui
- Functioning About Activity
- First time appear Activity
- Fast

## Upcoming Features
- notifications every 1 hour 
- user sign in 
- firebase integration

## How to use
Download the repository [Weather-app-in-android-studio](https://github.com/Sanjeevk03/Weather-app-in-Android-Studio)
Let the project build. It takes some time if you are building for first time
After build run the project and there you go!

## Contributions
Feel free to contribute to the project and add stuff!

# Note:
If you want apk file create an error and give me ur mail id.

Thanks!

# License:
```
MIT License

Copyright (c) [2023] [Weather-app-in-Android-Studio]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

```


